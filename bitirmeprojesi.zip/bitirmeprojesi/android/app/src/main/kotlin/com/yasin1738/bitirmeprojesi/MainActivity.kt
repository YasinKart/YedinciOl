package com.yasin1738.bitirmeprojesi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
