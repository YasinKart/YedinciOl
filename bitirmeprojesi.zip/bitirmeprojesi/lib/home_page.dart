import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  get user => FirebaseAuth.instance.currentUser!;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),

        child: ListView(
          padding: const EdgeInsets.all(16),
          children: <Widget>[
            Center(
              child:Text(
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30.0,),
                  'HABERLER'),
            ),
            SizedBox(height: 10),
            Center(
              child:Text(
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25.0,),
                  'Yeni Halı Sahalar Açılıyor!!!'),
            ),
            Container(
              color: Colors.white,
              child:
              Center(
                child: Image.network('https://media.istockphoto.com/id/637297320/tr/fotoğraf/view-of-soccer-field-illuminated-at-night.jpg?s=2048x2048&w=is&k=20&c=eu4pwInvjxRfaAslqOSb8Nk9jcwWtk9xgVEDvbCrSuI='),
              ),
            ),
            SizedBox(height: 20),

            Center(
              child:Text(
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25.0,),
                  "Süper Kupa Ertelendi"),
            ),
            Container(
              color: Colors.white,
              child: Center(
                  child:
                  Image.network('https://media.istockphoto.com/id/1159866054/tr/fotoğraf/stadyum-başında-atlet-tutan-kupa-fincan.jpg?s=2048x2048&w=is&k=20&c=SQAg-fGe-6pfcfiLuNcRGFJFWd04eWYiwJ7FE2rI0Rg=')
              ),
            ),
            SizedBox(height: 20),

            Center(
              child:Text(
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25.0,),
                  "Hakem Olaylarında Son Durum"),
            ),
            Container(
              color: Colors.white,
              child: Center(
                  child:
                  Image.network('https://media.istockphoto.com/id/185966428/tr/fotoğraf/referee-holding-up-a-red-card-and-whistle-inside-a-stadium.jpg?s=2048x2048&w=is&k=20&c=PZN3LiMzAs96f2TfR02me-6C0Nub4soYbIe3kjAXvro=')
              ),
            ),
            SizedBox(height: 20),

            Center(
              child:Text(
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25.0,),
                  "Alman Devi Bayern Defans Oyuncusu Arıyor!"),
            ),
            Container(
              color: Colors.white,
              child: Center(
                  child:
                  Image.network('https://media.istockphoto.com/id/1302871468/tr/fotoğraf/münih-stadyumu.jpg?s=2048x2048&w=is&k=20&c=lKvKgeIhnF9Mdutee10RgSuSgc3-UhSMWIlaTM-c1oc=')
              ),
            ),
            SizedBox(height: 20),

            Center(
              child:Text(
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25.0,),
                  "Transfermark Değerleri Günvellendi"),
            ),
            Container(
              color: Colors.white,
              child: Center(
                  child:
                  Image.network('https://media.istockphoto.com/id/539140953/tr/fotoğraf/sport.jpg?s=2048x2048&w=is&k=20&c=71vsb06bXHNis2GbImd6663rUB_9xdvdhBL9w_QnNHU=')
              ),
            ),





          ],
        ),




      ),

    );
  }
}